#!/usr/bin/env bash
# Только чистая установка. Старый комплект целиком переносится на рабочий стол.
set -Eeuo pipefail
[ "$EUID" -ne 0 ] || { echo 'Запустить без sudo.' >&2; exit 1; }
source_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P)"
target_dir="$HOME/bin/my-commands"
shortcut="$HOME/.local/share/applications/my-commands.desktop"
for dep in zenity x-terminal-emulator tee mktemp python3 xdg-user-dir; do
    command -v "$dep" >/dev/null || { echo "Не найден компонент: $dep" >&2; exit 1; }
done
/usr/bin/python3 -c 'import gi; gi.require_version("Gtk", "3.0"); from gi.repository import Gtk' || {
    echo 'Установить зависимости: sudo apt install python3-gi gir1.2-gtk-3.0 zenity xdg-user-dirs' >&2; exit 1;
}
for f in menu.sh install.sh; do bash -n "$source_dir/$f"; done
[ -f "$source_dir/menu-icon.svg" ] && [ -f "$source_dir/README.md" ]
case "$source_dir/" in "$target_dir/"*) echo 'Распаковать комплект вне ~/bin/my-commands.' >&2; exit 1;; esac
[ ! -L "$target_dir" ] && [ ! -L "$shortcut" ] || { echo 'Целевой каталог или ярлык является ссылкой; установка остановлена.' >&2; exit 1; }
[ ! -e "$target_dir" ] || [ -d "$target_dir" ] || { echo 'Вместо каталога установки найден файл.' >&2; exit 1; }
[ ! -e "$shortcut" ] || [ -f "$shortcut" ] || { echo 'Некорректный путь ярлыка.' >&2; exit 1; }
desktop_dir=$(xdg-user-dir DESKTOP)
[ -n "$desktop_dir" ] && [ "$desktop_dir" != "$HOME" ] && [ -d "$desktop_dir" ] && [ -w "$desktop_dir" ] || {
    echo 'Не найден отдельный доступный каталог рабочего стола. Настроить его через xdg-user-dirs.' >&2; exit 1;
}
mkdir -p "$HOME/bin" "$HOME/.local/share/applications"
stage_dir=$(mktemp -d "$HOME/bin/.my-commands-new-XXXXXX")
backup_dir=''
old_moved=0
shortcut_moved=0
new_installed=0
cleanup() {
    local status=$?
    trap - EXIT
    if [ "$status" -ne 0 ]; then
        if [ "$new_installed" -eq 1 ]; then
            mv -- "$target_dir" "$backup_dir/failed-new-installation" || true
        fi
        if [ "$old_moved" -eq 1 ]; then mv -- "$backup_dir/my-commands" "$target_dir" || true; fi
        if [ "$shortcut_moved" -eq 1 ]; then mv -- "$backup_dir/my-commands.desktop" "$shortcut" || true; fi
        printf 'Установка не завершена. Каталог сохранения: %s\n' "$backup_dir" >&2
    fi
    [ ! -d "$stage_dir" ] || rm -rf -- "$stage_dir"
    exit "$status"
}
trap cleanup EXIT
install -m 755 "$source_dir/menu.sh" "$stage_dir/menu.sh"
install -m 644 "$source_dir/menu-icon.svg" "$stage_dir/menu-icon.svg"
install -m 644 "$source_dir/README.md" "$stage_dir/README.md"
cat > "$stage_dir/launcher.desktop" <<EOF
[Desktop Entry]
Type=Application
Name=Мои команды
Comment=Системные команды и сайт АПС — 3.0.0
Exec="$target_dir/menu.sh"
Icon=$target_dir/menu-icon.svg
Terminal=false
StartupWMClass=MyCommands
Categories=Utility;
EOF
backup_dir=$(mktemp -d "$desktop_dir/my-commands-before-3.0.0-$(date +%Y%m%d-%H%M%S)-XXXXXX")
if [ -d "$target_dir" ]; then
    # mv сначала сохраняет весь комплект, затем убирает прежний рабочий каталог.
    mv -- "$target_dir" "$backup_dir/my-commands"
    old_moved=1
fi
if [ -f "$shortcut" ]; then
    mv -- "$shortcut" "$backup_dir/my-commands.desktop"
    shortcut_moved=1
fi
mv -- "$stage_dir" "$target_dir"
new_installed=1
install -m 644 "$target_dir/launcher.desktop" "$shortcut"
rm -- "$target_dir/launcher.desktop"
printf 'Чистая установка 3.0.0 завершена.\nПрежние файлы: %s\nЗапуск: %s/menu.sh\nКаталог сайта требуется выбрать заново.\n' "$backup_dir" "$target_dir"
