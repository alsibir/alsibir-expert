#!/usr/bin/env bash

# ============================================================
# МОИ КОМАНДЫ
# Панель системных и административных команд Linux Mint
#
# Классы операций:
#   ACTION    — штатное обратимое действие без терминала;
#   TERM      — безопасная/интерактивная команда в терминале;
#   CONFIRM   — изменение системы после подтверждения;
#   DANGEROUS — потенциально опасная операция с двойным
#               подтверждением.
# ============================================================


# ============================================================
# НАСТРОЙКИ
# ============================================================

# Редакция 3.0.0, 17.10.2026
BASE_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)" || exit 1

LOG_DIR="$BASE_DIR/logs"
LOG_FILE="$LOG_DIR/commands.log"
YANDEX_LOG_DIR="$LOG_DIR/yandex"
YDSK="$HOME/YDSK"
MENU_ICON="$BASE_DIR/menu-icon.svg"
ACTION_DONE=0
LAST_STATUS=0

# ============================================================
# ЖУРНАЛИРОВАНИЕ
# ============================================================

log_header() {
    local TYPE="$1"
    local TITLE="$2"
    shift 2

    {
        echo
        echo "============================================================"
        echo "Дата:    $(date '+%Y-%m-%d %H:%M:%S')"
        echo "Тип:     $TYPE"
        echo "Команда: $TITLE"

        printf "Запуск:  "
        printf "%q " "$@"
        echo

        echo "------------------------------------------------------------"
    } >> "$LOG_FILE"
}


log_result() {
    local STATUS="$1"

    {
        echo "------------------------------------------------------------"
        echo "Код завершения: $STATUS"
        echo "Завершено: $(date '+%Y-%m-%d %H:%M:%S')"
        echo "============================================================"
    } >> "$LOG_FILE"
}


log_cancel() {
    local TITLE="$1"

    {
        echo
        echo "============================================================"
        echo "Дата: $(date '+%Y-%m-%d %H:%M:%S')"
        echo "ОТМЕНЕНО: $TITLE"
        echo "============================================================"
    } >> "$LOG_FILE"
}


# ============================================================
# ACTION
# ============================================================

run_action() {
    local title="$1"; shift
    ACTION_DONE=1
    log_header ACTION "$title" "$@"
    local output status
    output=$("$@" 2>&1); status=$?
    printf '%s\n' "$output" >> "$LOG_FILE"
    log_result "$status"
    LAST_STATUS=$status
}

# Child writes completion only after Enter or closing the terminal.
terminal_child() {
    local result_dir="$1" logging="$2" title="$3"; shift 3
    local status=125
    trap 'printf "%s\n" "$status" > "$result_dir/done"' EXIT
    trap 'exit 130' INT
    trap 'exit 143' TERM HUP
    : > "$result_dir/ready"
    printf '\n%s\n\n' "$title"
    if [ "$logging" = yes ]; then
        "$@" 2>&1 | tee "$result_dir/output"
        status=${PIPESTATUS[0]}
        cat "$result_dir/output" >> "$LOG_FILE"
        log_result "$status"
    else
        "$@"; status=$?
    fi
    printf '\nКод завершения: %s\n' "$status"
    read -rp "Нажмите Enter для закрытия окна..." || true
    exit "$status"
}

open_terminal() {
    local logging="$1" title="$2"; shift 2
    ACTION_DONE=1
    local result_dir launcher i
    result_dir=$(mktemp -d) || { LAST_STATUS=125; return; }
    [ "$logging" = no ] || log_header "${OPERATION_TYPE:-TERM}" "$title" "$@"
    x-terminal-emulator -T "$title" -e bash "$BASE_DIR/menu.sh" \
        --terminal-child "$result_dir" "$logging" "$title" "$@" \
        2>"$result_dir/launcher-error" &
    launcher=$!
    for ((i=0; i<150; i++)); do
        [ ! -e "$result_dir/ready" ] || break
        [ ! -e "$result_dir/done" ] || break
        sleep 0.1
    done
    if [ ! -e "$result_dir/ready" ] && [ ! -e "$result_dir/done" ]; then
        cat "$result_dir/launcher-error" >> "$LOG_FILE"
        printf 'Терминал не запустился за 15 секунд.\n' >> "$LOG_FILE"
        LAST_STATUS=125
    else
        while [ ! -e "$result_dir/done" ]; do sleep 0.15; done
        LAST_STATUS=$(cat "$result_dir/done")
    fi
    # Launcher may stay attached until the terminal closes; it is not killed.
    rm -rf -- "$result_dir"
}

run_terminal() { local title="$1"; shift; open_terminal yes "$title" "$@"; }
run_terminal_no_log() { local title="$1"; shift; open_terminal no "$title" "$@"; }

# ============================================================
# CONFIRM
# ============================================================

run_confirm() {

    local TITLE="$1"
    local QUESTION="$2"

    shift 2

    zenity --question \
        --title="$TITLE" \
        --width=540 \
        --ok-label="Выполнить" \
        --cancel-label="Отмена" \
        --text="$QUESTION"

    if [ $? -ne 0 ]; then

        log_cancel "$TITLE"
        return

    fi

    OPERATION_TYPE=CONFIRM open_terminal yes "$TITLE" "$@"

}


# ============================================================
# DANGEROUS
# ============================================================

run_dangerous() {

    local TITLE="$1"
    local DESCRIPTION="$2"

    shift 2

    local ANSWER

    ANSWER=$(zenity --entry \
        --title="$TITLE" \
        --width=560 \
        --text="$DESCRIPTION

ВНИМАНИЕ.

Операция потенциально опасна и может привести
к потере данных.

Для продолжения введите:

ПОДТВЕРЖДАЮ")

    if [ "$ANSWER" != "ПОДТВЕРЖДАЮ" ]; then

        log_cancel "$TITLE"

        zenity --info \
            --title="$TITLE" \
            --text="Операция отменена."

        return

    fi

    run_confirm \
        "$TITLE" \
        "Получено текстовое подтверждение.

Выполнить операцию?" \
        "$@"
}


# ============================================================
# ADGUARD VPN — ПРОВЕРКА СОСТОЯНИЯ
#
# Возвращает:
#   0 — VPN подключён по данным adguardvpn-cli status;
#   1 — VPN не подключён.
# ============================================================

vpn_is_connected() {

    LC_ALL=C adguardvpn-cli status 2>&1 |
        grep -q '^Connected to '
}


# ============================================================
# ADGUARD VPN — ЗАЩИЩЁННОЕ ПОДКЛЮЧЕНИЕ
#
# Не запускает второй экземпляр, если status уже сообщает
# о существующем подключении.
# ============================================================

vpn_connect() {

    local LOCATION="$1"
    local TITLE="$2"

    if vpn_is_connected; then

        local CURRENT_STATUS

        CURRENT_STATUS=$(LC_ALL=C adguardvpn-cli status 2>&1)

        zenity --info \
            --title="AdGuard VPN" \
            --width=540 \
            --text="VPN уже подключён.

$CURRENT_STATUS

Сначала отключите текущее VPN-соединение."

        return
    fi

    if [ -n "$LOCATION" ]; then

        run_terminal \
            "$TITLE" \
            adguardvpn-cli connect -l "$LOCATION"

    else

        run_terminal \
            "$TITLE" \
            adguardvpn-cli connect

    fi
}


# ============================================================
# ADGUARD VPN — РАСШИРЕННАЯ ДИАГНОСТИКА
# ============================================================

vpn_diagnostics() {

    run_terminal \
        "AdGuard VPN — расширенное состояние" \
        bash -c '

            echo "===== ADGUARD VPN STATUS ====="
            echo

            STATUS_OUTPUT=$(LC_ALL=C adguardvpn-cli status 2>&1)
            STATUS_CODE=$?

            echo "$STATUS_OUTPUT"
            echo
            echo "Код status: $STATUS_CODE"

            echo
            echo "===== ПРОЦЕССЫ ADGUARD VPN ====="
            echo

            VPN_PROCESSES=$(ps -eo user,pid,ppid,stat,etime,args | grep "/opt/adguardvpn_cli/adguardvpn-cli connect --no-fork" | grep -v -E "gnome-terminal|bash -c|grep ")


            if [ -n "$VPN_PROCESSES" ]; then
                echo "$VPN_PROCESSES"
                PROCESS_PRESENT=1
            else
                echo "Процессы AdGuard VPN не найдены."
                PROCESS_PRESENT=0
            fi

            echo
            echo "===== TUN/TAP ====="
            echo

            TUN_OUTPUT=$(ip -brief link | grep -E "tun|tap")

            if [ -n "$TUN_OUTPUT" ]; then
                echo "$TUN_OUTPUT"
                TUN_PRESENT=1
            else
                echo "TUN/TAP не найден."
                TUN_PRESENT=0
            fi

            echo
            echo "===== VPN.PID ====="
            echo

            PID_FILE="$HOME/.local/share/adguardvpn-cli/vpn.pid"

            if [ -f "$PID_FILE" ]; then

                echo "Файл существует:"
                echo "$PID_FILE"
                echo
                echo "Содержимое:"
                cat "$PID_FILE"
                PID_PRESENT=1

            else

                echo "Файл vpn.pid отсутствует:"
                echo "$PID_FILE"
                PID_PRESENT=0

            fi

            echo
            echo "===== ИТОГОВАЯ ПРОВЕРКА ====="
            echo

            if echo "$STATUS_OUTPUT" | grep -q "^Connected to "; then
                STATUS_CONNECTED=1
            else
                STATUS_CONNECTED=0
            fi

            if [ "$STATUS_CONNECTED" -eq 1 ]; then

                echo "CLI сообщает: VPN ПОДКЛЮЧЁН."

                if [ "$PROCESS_PRESENT" -eq 0 ]; then
                    echo "ПРЕДУПРЕЖДЕНИЕ: VPN-процесс не найден."
                fi

                if [ "$TUN_PRESENT" -eq 0 ]; then
                    echo "ПРЕДУПРЕЖДЕНИЕ: TUN/TAP-интерфейс не найден."
                fi

                if [ "$PID_PRESENT" -eq 0 ]; then
                    echo "ПРЕДУПРЕЖДЕНИЕ: vpn.pid отсутствует."
                fi

            else

                echo "CLI сообщает: VPN НЕ ПОДКЛЮЧЁН."

                if [ "$PROCESS_PRESENT" -eq 1 ]; then
                    echo "ПРЕДУПРЕЖДЕНИЕ:"
                    echo "CLI считает VPN отключённым, но процесс AdGuard VPN существует."
                fi

                if [ "$TUN_PRESENT" -eq 1 ]; then
                    echo "ПРЕДУПРЕЖДЕНИЕ:"
                    echo "CLI считает VPN отключённым, но TUN/TAP-интерфейс существует."
                fi

                if [ "$PID_PRESENT" -eq 1 ]; then
                    echo "ПРЕДУПРЕЖДЕНИЕ:"
                    echo "CLI считает VPN отключённым, но vpn.pid существует."
                fi

            fi
        '
}


# ============================================================
# ПОЛНАЯ ДИАГНОСТИКА ЯНДЕКС.ДИСКА
# ============================================================

yandex_full_diagnostics() {
    run_terminal "Полная диагностика Яндекс.Диска" bash "$BASE_DIR/menu.sh" --yandex-report
}


# ============================================================
# МЕНЮ: ЯНДЕКС.ДИСК
# ============================================================

menu_yandex() {

    while true
    do

        CHOICE=$(zenity --list --window-icon="$MENU_ICON" \
            --title="Яндекс.Диск" \
            --width=700 \
            --height=570 \
            --column="Действие" \
            "Полная диагностика" \
            "Статус Яндекс.Диска" \
            "Запустить Яндекс.Диск" \
            "Остановить Яндекс.Диск" \
            "Перезапустить Яндекс.Диск" \
            "Проверить процесс Яндекс.Диска" \
            "Проверить cpulimit" \
            "Открыть диагностические отчёты" \
            "Удалить отчёты старше 90 дней" \
            "Назад")

        case "$CHOICE" in


            "Полная диагностика")

                yandex_full_diagnostics
                ;;


            "Статус Яндекс.Диска")

                run_terminal \
                    "Яндекс.Диск — состояние" \
                    yandex-disk status
                ;;


            "Запустить Яндекс.Диск")

                run_action \
                    "Яндекс.Диск запущен" \
                    yandex-disk start
                ;;


            "Остановить Яндекс.Диск")

                run_action \
                    "Яндекс.Диск остановлен" \
                    yandex-disk stop
                ;;


            "Перезапустить Яндекс.Диск")

                run_confirm \
                    "Перезапуск Яндекс.Диска" \
                    "Служба синхронизации Яндекс.Диска будет перезапущена.

Продолжить?" \
                    bash -c \
                    'yandex-disk stop && sleep 2 && yandex-disk start'
                ;;


            "Проверить процесс Яндекс.Диска")

                run_terminal \
                    "Процесс Яндекс.Диска" \
                    bash -c \
                    'PID=$(pgrep -x yandex-disk | head -1);
                     if [ -n "$PID" ]; then
                         echo "PID=$PID";
                         echo;
                         ps -p "$PID" \
                           -o pid,%cpu,%mem,rss,vsz,etime,stat,cmd;
                     else
                         echo "Процесс yandex-disk не найден.";
                     fi'
                ;;


            "Проверить cpulimit")

                run_terminal \
                    "cpulimit — состояние" \
                    bash -c \
                    'if pgrep -x cpulimit >/dev/null; then
                         pgrep -a cpulimit;
                     else
                         echo "Процесс cpulimit не обнаружен.";
                     fi'
                ;;


            "Открыть диагностические отчёты")

                run_action "Открытие отчётов" xdg-open "$YANDEX_LOG_DIR"
                ;;


            "Удалить отчёты старше 90 дней")

                run_confirm \
                    "Очистка диагностических отчётов" \
                    "Будут удалены диагностические отчёты Яндекс.Диска старше 90 дней.

Каталог:

$YANDEX_LOG_DIR

Удаляются только файлы вида:

yandex-*.log

Продолжить?" \
                    find "$YANDEX_LOG_DIR" \
                    -type f \
                    -name 'yandex-*.log' \
                    -mtime +90 \
                    -delete
                ;;


            "Назад"|"")

                return
                ;;

        esac
        ACTION_DONE=0  # Следующая команда выбирается в этом же подменю.

    done
}


# ============================================================
# МЕНЮ: ADGUARD VPN
# ============================================================

menu_vpn() {

    while true
    do

        CHOICE=$(zenity --list --window-icon="$MENU_ICON" \
            --title="AdGuard VPN" \
            --width=680 \
            --height=780 \
            --column="Действие" \
            "Статус VPN" \
            "Расширенная диагностика VPN" \
            "Подключить VPN" \
            "Подключить Финляндию" \
            "Подключить Нидерланды" \
            "Подключить Италию" \
            "Подключить Испанию" \
            "Подключить Швецию" \
            "Подключить Австрию" \
            "Подключить Бельгию" \
            "Подключить Лондон" \
            "Подключить Латвию" \
            "Подключить Польшу" \
            "Подключить США" \
            "Доступные локации VPN" \
            "Отключить VPN" \
            "Назад")

        case "$CHOICE" in


            "Статус VPN")

                run_terminal \
                    "AdGuard VPN — состояние" \
                    adguardvpn-cli status
                ;;


            "Расширенная диагностика VPN")

                vpn_diagnostics
                ;;


            "Подключить VPN")

                vpn_connect \
                    "" \
                    "AdGuard VPN — подключение"
                ;;


            "Подключить Финляндию")

                vpn_connect \
                    "fi" \
                    "AdGuard VPN — Финляндия"
                ;;


            "Подключить Нидерланды")

                vpn_connect \
                    "nl" \
                    "AdGuard VPN — Нидерланды"
                ;;


            "Подключить Италию")
                vpn_connect "IT" "AdGuard VPN — Италию"
                ;;

            "Подключить Испанию")
                vpn_connect "ES" "AdGuard VPN — Испанию"
                ;;

            "Подключить Швецию")
                vpn_connect "SE" "AdGuard VPN — Швецию"
                ;;

            "Подключить Австрию")
                vpn_connect "AT" "AdGuard VPN — Австрию"
                ;;

            "Подключить Бельгию")
                vpn_connect "BE" "AdGuard VPN — Бельгию"
                ;;

            "Подключить Лондон")
                vpn_connect "London" "AdGuard VPN — Лондон"
                ;;

            "Подключить Латвию")
                vpn_connect "LV" "AdGuard VPN — Латвию"
                ;;

            "Подключить Польшу")
                vpn_connect "PL" "AdGuard VPN — Польшу"
                ;;

            "Подключить США")
                vpn_connect "US" "AdGuard VPN — США"
                ;;

            "Доступные локации VPN")
                run_terminal "Доступные локации VPN" adguardvpn-cli list-locations
                ;;

            "Отключить VPN")

                run_terminal \
                    "AdGuard VPN — отключение" \
                    adguardvpn-cli disconnect
                ;;


            "Назад"|"")

                return
                ;;

        esac
        ACTION_DONE=0  # Следующая команда выбирается в этом же подменю.

    done
}


# ============================================================
# МЕНЮ: ДИСКИ И ФАЙЛОВЫЕ СИСТЕМЫ
# ============================================================

menu_disks() {

    while true
    do

        CHOICE=$(zenity --list --window-icon="$MENU_ICON" \
            --title="Диски и файловые системы" \
            --width=700 \
            --height=500 \
            --column="Действие" \
            "Список дисков и разделов" \
            "Свободное место" \
            "Точки монтирования" \
            "Использование inode" \
            "UUID и файловые системы" \
            "Назад")

        case "$CHOICE" in


            "Список дисков и разделов")

                run_terminal \
                    "Диски и разделы" \
                    lsblk \
                    -o NAME,SIZE,FSTYPE,LABEL,UUID,MOUNTPOINTS
                ;;


            "Свободное место")

                run_terminal \
                    "Свободное место" \
                    df -hT
                ;;


            "Точки монтирования")

                run_terminal \
                    "Точки монтирования" \
                    findmnt
                ;;


            "Использование inode")

                run_terminal \
                    "Использование inode" \
                    df -ih
                ;;


            "UUID и файловые системы")

                run_terminal \
                    "UUID и файловые системы" \
                    lsblk -f
                ;;


            "Назад"|"")

                return
                ;;

        esac
        ACTION_DONE=0  # Следующая команда выбирается в этом же подменю.

    done
}


# ============================================================
# МЕНЮ: СИСТЕМА
# ============================================================

menu_system() {

    while true
    do

        CHOICE=$(zenity --list --window-icon="$MENU_ICON" \
            --title="Система" \
            --width=720 \
            --height=600 \
            --column="Действие" \
            "Использование памяти" \
            "Время работы системы" \
            "Наиболее активные процессы" \
            "Ошибки текущей загрузки" \
            "Обновить список пакетов" \
            "Обновить установленные пакеты" \
            "Перезагрузить компьютер" \
            "Выключить компьютер" \
            "Назад")

        case "$CHOICE" in


            "Использование памяти")

                run_terminal \
                    "Использование памяти" \
                    free -h
                ;;


            "Время работы системы")

                run_terminal \
                    "Время работы системы" \
                    uptime
                ;;


            "Наиболее активные процессы")

                run_terminal \
                    "Наиболее активные процессы" \
                    bash -c \
                    'ps aux --sort=-%cpu | head -25'
                ;;


            "Ошибки текущей загрузки")

                run_terminal \
                    "Ошибки текущей загрузки" \
                    journalctl \
                    -p err \
                    -b \
                    --no-pager
                ;;


            "Обновить список пакетов")

                run_terminal \
                    "APT — обновление списка пакетов" \
                    sudo apt update
                ;;


            "Обновить установленные пакеты")

                run_confirm \
                    "Обновление системы" \
                    "Будут обновлены установленные пакеты.

Перед выполнением рекомендуется закрыть важные приложения.

Продолжить?" \
                    sudo apt upgrade
                ;;


            "Перезагрузить компьютер")

                run_confirm \
                    "Перезагрузка компьютера" \
                    "Компьютер будет перезагружен.

Несохранённые данные могут быть потеряны.

Продолжить?" \
                    sudo reboot
                ;;


            "Выключить компьютер")

                run_confirm \
                    "Выключение компьютера" \
                    "Компьютер будет выключен.

Несохранённые данные могут быть потеряны.

Продолжить?" \
                    sudo poweroff
                ;;


            "Назад"|"")

                return
                ;;

        esac
        ACTION_DONE=0  # Следующая команда выбирается в этом же подменю.

    done
}


# ============================================================
# МЕНЮ: ЖУРНАЛЫ
# ============================================================

menu_logs() {

    while true
    do

        CHOICE=$(zenity --list --window-icon="$MENU_ICON" \
            --title="Журналы" \
            --width=700 \
            --height=500 \
            --column="Действие" \
            "Последние 100 строк общего журнала" \
            "Просмотреть весь общий журнал" \
            "Открыть каталог журналов" \
            "Открыть отчёты Яндекс.Диска" \
            "Очистить общий журнал" \
            "Назад")

        case "$CHOICE" in


            "Последние 100 строк общего журнала")

                run_terminal_no_log \
                    "Последние записи журнала" \
                    tail -n 100 "$LOG_FILE"
                ;;


            "Просмотреть весь общий журнал")

                run_terminal_no_log "Общий журнал команд (выход: Q)" less "$LOG_FILE"
                ;;


            "Открыть каталог журналов")

                run_action "Открытие журналов" xdg-open "$LOG_DIR"
                ;;


            "Открыть отчёты Яндекс.Диска")

                run_action "Открытие отчётов" xdg-open "$YANDEX_LOG_DIR"
                ;;


            "Очистить общий журнал")

                run_confirm \
                    "Очистка общего журнала" \
                    "Будет очищено содержимое общего журнала:

$LOG_FILE

Диагностические отчёты Яндекс.Диска удалены не будут.

Продолжить?" \
                    truncate -s 0 "$LOG_FILE"
                ;;


            "Назад"|"")

                return
                ;;

        esac
        ACTION_DONE=0  # Следующая команда выбирается в этом же подменю.

    done
}



embedded_yandex_report() (
BASE_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)" || exit 2
LOG_DIR="$BASE_DIR/logs/yandex"

/usr/bin/python3 -c 'import gi; gi.require_version("Gtk", "3.0"); from gi.repository import Gtk' || {
    echo 'Требуются python3-gi и gir1.2-gtk-3.0.' >&2; exit 1;
}
mkdir -p "$LOG_DIR" || exit 2
umask 077

TIMESTAMP=$(date '+%Y-%m-%d_%H-%M-%S')
REPORT=$(mktemp "$LOG_DIR/yandex-$TIMESTAMP-XXXXXX.log") || exit 2

WARNINGS=0
ERRORS=0


section() {
    echo
    echo "============================================================"
    echo "$1"
    echo "============================================================"
}


warning() {
    echo "ПРЕДУПРЕЖДЕНИЕ: $1"
    WARNINGS=$((WARNINGS + 1))
}


error() {
    echo "ОШИБКА: $1"
    ERRORS=$((ERRORS + 1))
}


# ------------------------------------------------------------
# Весь вывод одновременно:
# 1. на экран;
# 2. в отдельный диагностический файл.
# ------------------------------------------------------------

# Сохраняются исходные дескрипторы, чтобы дождаться записи отчёта.
exec 3>&1 4>&2
exec > >(tee "$REPORT") 2>&1
REPORT_WRITER=$!
finish_report() {
    local result=$?
    trap - EXIT
    exec 1>&3 2>&4
    if ! wait "$REPORT_WRITER"; then
        printf 'Ошибка записи отчёта: %s\n' "$REPORT" >&2
        result=2
    fi
    exit "$result"
}
trap finish_report EXIT


section "ДАТА И ВРЕМЯ"

date '+%d.%m.%Y %H:%M:%S'

echo "Компьютер: $(hostname)"
echo "Пользователь: $(whoami)"


# ============================================================
# ПРОЦЕСС ЯНДЕКС.ДИСКА
# ============================================================

section "YANDEX-DISK — ПРОЦЕСС"

PID=$(pgrep -u "$(id -u)" -x yandex-disk | head -1)

if [ -n "$PID" ]; then

    echo "PID=$PID"
    echo

    ps -p "$PID" \
        -o pid,%cpu,%mem,rss,vsz,etime,stat,cmd

else

    error "Процесс yandex-disk не найден."

fi


# ============================================================
# CPULIMIT
# ============================================================

section "CPULIMIT"

if pgrep -x cpulimit >/dev/null; then

    pgrep -a cpulimit

else

    warning "Процесс cpulimit не обнаружен."

fi


# ============================================================
# ПРОВЕРКА СВЯЗКИ YANDEX-DISK → CPULIMIT
# ============================================================

section "СВЯЗКА YANDEX-DISK → CPULIMIT"

if [ -n "$PID" ]; then

    CPULIMIT_LINES=$(pgrep -a cpulimit)

    if echo "$CPULIMIT_LINES" | grep -Eq -- "-p[ =]+$PID([[:space:]]|$)"; then

        echo "Яндекс.Диск PID: $PID"
        echo "cpulimit ограничивает PID: $PID"
        echo
        echo "Результат: OK"

    else

        warning "cpulimit не обнаружен для текущего PID Яндекс.Диска ($PID)."

    fi

else

    echo "Связка не проверялась: yandex-disk не запущен."

fi


# ============================================================
# СТАТУС ЯНДЕКС.ДИСКА
# ============================================================

section "YANDEX-DISK STATUS"

STATUS_OUTPUT=$(yandex-disk status 2>&1)
STATUS_CODE=$?

echo "$STATUS_OUTPUT"

if [ "$STATUS_CODE" -ne 0 ]; then

    error "Команда yandex-disk status завершилась с кодом $STATUS_CODE."

fi


# ------------------------------------------------------------
# Поиск сообщений об ошибках
# ------------------------------------------------------------

if echo "$STATUS_OUTPUT" | grep -qiE \
    'ошибка|error|failed|failure'; then

    error "В состоянии Яндекс.Диска обнаружено сообщение об ошибке."

fi


# ------------------------------------------------------------
# Проверка известной ошибки заполнения диска
# ------------------------------------------------------------

if echo "$STATUS_OUTPUT" | grep -qi \
    'диск переполнен'; then

    error "Яндекс.Диск сообщает: Диск переполнен."

fi


# ============================================================
# ФАЙЛОВАЯ СИСТЕМА YDSK
# ============================================================

section "ФАЙЛОВАЯ СИСТЕМА YDSK"

YDSK="$HOME/YDSK"

if [ -d "$YDSK" ]; then

    df -hT "$YDSK"

    USED=$(df -P "$YDSK" | awk 'NR==2 {gsub("%","",$5); print $5}')

    echo
    echo "Использовано: ${USED}%"

    if [[ ! "$USED" =~ ^[0-9]+$ ]]; then
        error "Не удалось определить заполнение файловой системы."
    elif [ "$USED" -ge 95 ]; then

        error "Файловая система заполнена на ${USED}%."

    elif [ "$USED" -ge 85 ]; then

        warning "Файловая система заполнена на ${USED}%."

    else

        echo "Результат: OK"

    fi

else

    error "Каталог $YDSK не найден."

fi


# ============================================================
# ПАМЯТЬ
# ============================================================

section "ОПЕРАТИВНАЯ ПАМЯТЬ"

free -h


# ============================================================
# НАГРУЗКА
# ============================================================

section "НАГРУЗКА СИСТЕМЫ"

uptime

echo

if [ -n "$PID" ]; then

    ps -p "$PID" \
        -o pid,%cpu,%mem,rss,vsz,etime,stat

fi


# ============================================================
# ПОСЛЕДНИЕ СООБЩЕНИЯ YANDEX-DISK
# ============================================================

section "ПОСЛЕДНИЕ СИНХРОНИЗИРОВАННЫЕ ПУТИ"

echo "$STATUS_OUTPUT" |
    sed -n '/Последние синхронизированные пути:/,$p'


# ============================================================
# ИТОГОВАЯ ОЦЕНКА
# ============================================================

section "ИТОГОВАЯ ОЦЕНКА"

echo "Ошибок:        $ERRORS"
echo "Предупреждений: $WARNINGS"
echo


if [ "$ERRORS" -gt 0 ]; then

    echo "СОСТОЯНИЕ: ОШИБКА"

    RESULT=2

elif [ "$WARNINGS" -gt 0 ]; then

    echo "СОСТОЯНИЕ: ПРЕДУПРЕЖДЕНИЕ"

    RESULT=1

else

    echo "СОСТОЯНИЕ: OK"

    RESULT=0

fi


echo
echo "Диагностический отчёт:"
echo "$REPORT"

echo
echo "============================================================"
echo "Диагностика завершена."
echo "============================================================"

exit "$RESULT"

)

embedded_astro() (
set -Eeuo pipefail
SCRIPT_DIR="$BASE_DIR"
SOURCE_DIR="${ASTRO_USB_SOURCE:-${SCRIPT_DIR}/projects/alsibir-expert}"
WORK_DIR="${ASTRO_LINUX_WORKDIR:-${HOME}/.cache/alsibir-expert-linux}"
MARKER='.alsibir-astro-linux-workdir'
STAMP='.alsibir-astro-deps.sha256'
MODE="${1:-dev}"

show_help() {
  cat <<'HELP'
Использование: bash start-astro-linux.sh [dev|build|preview|sync|check]
  dev    Синхронизировать и запустить сервер (по умолчанию)
  build  Синхронизировать и проверить сборку
  preview Синхронизировать и просмотреть результат ранее выполненной сборки
  sync   Синхронизировать проект без установки зависимостей
  check  Проверить пути, Node.js и основные файлы без изменений

Источник:  projects/alsibir-expert рядом со скриптом (или ASTRO_USB_SOURCE)
Рабочая копия: $HOME/.cache/alsibir-expert-linux
Для изменения путей задайте ASTRO_USB_SOURCE и ASTRO_LINUX_WORKDIR.
HELP
}

if [[ "$MODE" == '-h' || "$MODE" == '--help' ]]; then
  show_help
  exit 0
fi
if [[ "$MODE" != 'dev' && "$MODE" != 'build' && "$MODE" != 'preview' && "$MODE" != 'sync' && "$MODE" != 'check' ]]; then
  show_help >&2
  exit 2
fi

for executable in rsync sha256sum; do
  if ! command -v "$executable" >/dev/null 2>&1; then
    printf 'Отсутствует программа: %s\n' "$executable" >&2
    exit 1
  fi
done

if [[ ! -d "$SOURCE_DIR" || ! -f "$SOURCE_DIR/package.json" || ! -f "$SOURCE_DIR/astro.config.mjs" || ! -d "$SOURCE_DIR/src" ]]; then
  printf 'Не найден проект Astro: %s\nПроверьте подключение флешки и точку монтирования.\n' "$SOURCE_DIR" >&2
  exit 1
fi

# Загрузить установленный nvm, не изменяя системную версию Node.js.
export NVM_DIR="${NVM_DIR:-${HOME}/.nvm}"
if [[ -s "$NVM_DIR/nvm.sh" ]]; then
  # shellcheck source=/dev/null
  . "$NVM_DIR/nvm.sh"
  if nvm ls 24 2>/dev/null | grep -q 'v24'; then
    nvm use 24 >/dev/null
  fi
fi

if ! command -v node >/dev/null 2>&1 || ! command -v npm >/dev/null 2>&1; then
  printf 'Node.js/npm не найдены. Установите Node.js 24 через nvm.\n' >&2
  exit 1
fi

node_major="$(node -p 'process.versions.node.split(".")[0]')"
node_minor="$(node -p 'process.versions.node.split(".")[1]')"
if [[ "$node_major" -lt 22 || ( "$node_major" -eq 22 && "$node_minor" -lt 12 ) ]]; then
  printf 'Несовместимая Node.js: %s. Требуется версия >=22.12 (рекомендуется 24).\n' "$(node --version)" >&2
  exit 1
fi

printf 'Исходный проект: %s\n' "$SOURCE_DIR"
printf 'Рабочая копия:  %s\n' "$WORK_DIR"
printf 'Node.js:         %s\n' "$(node --version)"
printf 'npm:             %s\n' "$(npm --version)"

if [[ "$MODE" == 'check' ]]; then
  printf 'Проверка пройдена. Файлы не изменены.\n'
  exit 0
fi

# Не использовать rsync --delete в чужом каталоге.
if [[ -e "$WORK_DIR" && ! -f "$WORK_DIR/$MARKER" ]]; then
  if [[ -n "$(ls -A "$WORK_DIR")" ]]; then
    printf 'Рабочий каталог существует, но не помечен как управляемый:\n%s\n' "$WORK_DIR" >&2
    printf 'Укажите другой ASTRO_LINUX_WORKDIR либо проверьте каталог вручную.\n' >&2
    exit 1
  fi
fi
mkdir -p "$WORK_DIR"
: > "$WORK_DIR/$MARKER"

# Исключения защищают Linux-зависимости и локальные файлы состояния от --delete.
rsync -rt --delete \
  --exclude='/node_modules/' \
  --exclude='/.astro/' \
  --exclude='/dist/' \
  --exclude='/.git/' \
  --exclude="/$MARKER" \
  --exclude="/$STAMP" \
  --exclude='/*.zip' \
  --exclude='/desktop.ini' \
  "$SOURCE_DIR/" "$WORK_DIR/"

printf 'Синхронизация завершена. Источник на флешке не изменён.\n'
if [[ "$MODE" == 'sync' ]]; then
  exit 0
fi

cd "$WORK_DIR"

if [[ ! -f package-lock.json ]]; then
  printf 'Не найден package-lock.json. Установка зависимостей остановлена.\n' >&2
  exit 1
fi

# Проверять целостность набора зависимостей при изменении package*.json или Node.js.
deps_fingerprint="$( { sha256sum package.json package-lock.json; node --version; } | sha256sum | cut -d ' ' -f 1 )"
previous_fingerprint=''
if [[ -f "$STAMP" ]]; then
  previous_fingerprint="$(cat "$STAMP")"
fi
if [[ ! -d node_modules || "$deps_fingerprint" != "$previous_fingerprint" ]]; then
  printf 'Установка Linux-зависимостей в %s ...\n' "$WORK_DIR"
  npm ci --no-audit --no-fund
  printf '%s\n' "$deps_fingerprint" > "$STAMP"
else
  printf 'Linux-зависимости актуальны; повторная установка не требуется.\n'
fi

if [[ "$MODE" == 'build' ]]; then
  npm run build
elif [[ "$MODE" == 'preview' ]]; then
  if [[ ! -d dist ]]; then printf 'Отсутствует dist. Сначала запустите build.\n' >&2; exit 1; fi
  npm run preview -- --host 127.0.0.1
else
  printf 'Откройте: http://localhost:4321/blog/\n'
  printf 'Для остановки сервера нажмите Ctrl+C.\n'
  npm run dev -- --host 127.0.0.1
fi

)
site_config() {
    local config="$BASE_DIR/site.conf"
    [ -f "$config" ] || { echo 'Сначала выбрать каталог исходного проекта в меню сайта.' >&2; return 1; }
    # Configuration is plain text, never sourced as shell code.
    IFS= read -r ASTRO_USB_SOURCE < "$config" || true
    [ -f "$ASTRO_USB_SOURCE/package.json" ] && [ -f "$ASTRO_USB_SOURCE/astro.config.mjs" ] && [ -d "$ASTRO_USB_SOURCE/src" ] || {
        echo "Проект недоступен: $ASTRO_USB_SOURCE" >&2; return 1;
    }
    export ASTRO_USB_SOURCE
    export ASTRO_LINUX_WORKDIR="$HOME/.cache/alsibir-expert-linux"
}

site_command() {
    local action="$1"; shift
    site_config || return 1
    local state="$BASE_DIR/site-state"
    mkdir -p "$state" || return 1
    case "$action" in
        check) embedded_astro check ;;
        sync|build|preview)
            command -v flock >/dev/null || { echo 'Не найден flock.'; return 1; }
            flock -n "$state/work.lock" bash "$BASE_DIR/menu.sh" --astro "$action"
            ;;
        dev)
            command -v systemd-run >/dev/null || { echo 'Не найден systemd-run.'; return 1; }
            if systemctl --user is-active --quiet aps-site-dev.service; then
                echo 'Сервер сайта уже запущен.'; return 0
            fi
            systemd-run --user --collect --unit=aps-site-dev \
                --description='АПС: локальный сервер Astro' \
                --property=KillMode=control-group \
                flock -n "$state/work.lock" bash "$BASE_DIR/menu.sh" --astro dev || return
            echo 'Запуск передан пользовательской службе. Состояние и ошибки доступны в меню сайта.'
            echo 'Адрес: http://localhost:4321/blog/ (при занятом порте см. журнал).'
            ;;
        stop) systemctl --user stop aps-site-dev.service ;;
        status)
            systemctl --user status aps-site-dev.service --no-pager
            ;;
        logs) journalctl --user -u aps-site-dev.service -n 120 --no-pager ;;
        backup)
            local archive="$HOME/site-backups"
            mkdir -p "$archive" || return 1
            archive=$(mktemp "$archive/alsibir-expert-$(date +%Y%m%d-%H%M%S)-XXXXXX.tar.gz") || return 1
            if tar --exclude='./node_modules' --exclude='./dist' --exclude='./.astro' --exclude='./.git' \
                -czf "$archive" -C "$ASTRO_USB_SOURCE" .; then
                printf 'Резервная копия: %s\n' "$archive"
            else
                echo 'Резервная копия не завершена; файл нельзя считать исправным.' >&2
                return 1
            fi
            ;;
        source) xdg-open "$ASTRO_USB_SOURCE" ;;
        dist)
            [ -d "$ASTRO_LINUX_WORKDIR/dist" ] || { echo 'Сначала выполнить сборку.'; return 1; }
            xdg-open "$ASTRO_LINUX_WORKDIR/dist"
            ;;
        browser) xdg-open 'http://localhost:4321/blog/' ;;
        *) echo 'Неизвестная операция сайта.' >&2; return 2 ;;
    esac
}

menu_site() {
    local selection path
    while true; do
        selection=$(zenity --list --title="Сайт АПС" --window-icon="$MENU_ICON" \
            --width=780 --height=650 --column="Действие" \
            "Выбрать исходный проект" "Проверить окружение сайта" \
            "Синхронизировать рабочую копию" "Запустить локальный сервер" \
            "Остановить локальный сервер" "Состояние локального сервера" \
            "Журнал локального сервера" "Открыть сайт в браузере" \
            "Собрать сайт" "Просмотр сборки (Ctrl+C для остановки)" \
            "Резервная копия исходников" "Открыть исходный проект" \
            "Открыть dist для публикации" "Назад") || return
        case "$selection" in
            "Выбрать исходный проект")
                path=$(zenity --file-selection --directory --title="Выбрать projects/alsibir-expert") || continue
                if [ -f "$path/package.json" ] && [ -f "$path/astro.config.mjs" ] && [ -d "$path/src" ]; then
                    printf '%s\n' "$path" > "$BASE_DIR/site.conf"
                    ACTION_DONE=1; LAST_STATUS=$?
                else
                    zenity --error --text="В выбранном каталоге нет package.json, astro.config.mjs или src."
                fi
                ;;
            "Проверить окружение сайта") run_terminal "Проверка сайта" bash "$BASE_DIR/menu.sh" --site check ;;
            "Синхронизировать рабочую копию") run_confirm "Синхронизация сайта" "Рабочая Linux-копия будет приведена к исходникам. Изменения только в рабочей копии могут быть удалены. Продолжить?" bash "$BASE_DIR/menu.sh" --site sync ;;
            "Запустить локальный сервер") run_confirm "Запуск сайта" "Синхронизировать исходники и запустить локальный сервер? Он продолжит работу после закрытия меню; остановка доступна в меню сайта." bash "$BASE_DIR/menu.sh" --site dev ;;
            "Остановить локальный сервер") run_terminal "Остановка сайта" bash "$BASE_DIR/menu.sh" --site stop ;;
            "Состояние локального сервера") run_terminal "Состояние сайта" bash "$BASE_DIR/menu.sh" --site status ;;
            "Журнал локального сервера") run_terminal "Журнал сайта" bash "$BASE_DIR/menu.sh" --site logs ;;
            "Открыть сайт в браузере") run_action "Открытие сайта" bash "$BASE_DIR/menu.sh" --site browser ;;
            "Собрать сайт") run_confirm "Сборка сайта" "Синхронизировать рабочую копию и выполнить сборку? Установка зависимостей при необходимости требует Интернета." bash "$BASE_DIR/menu.sh" --site build ;;
            "Просмотр сборки (Ctrl+C для остановки)") run_confirm "Просмотр сборки" "Синхронизировать рабочую копию и открыть ранее собранный dist? Он может не соответствовать текущим исходникам: сначала рекомендуется сборка." bash "$BASE_DIR/menu.sh" --site preview ;;
            "Резервная копия исходников") run_terminal "Резервная копия сайта" bash "$BASE_DIR/menu.sh" --site backup ;;
            "Открыть исходный проект") run_action "Исходный проект" bash "$BASE_DIR/menu.sh" --site source ;;
            "Открыть dist для публикации") run_action "Готовая сборка" bash "$BASE_DIR/menu.sh" --site dist ;;
            *) return ;;
        esac
        ACTION_DONE=0  # Следующая команда выбирается в этом же подменю.
    done
}

main_dialog() {
    /usr/bin/python3 - "$MENU_ICON" <<'PYGTK'
import sys
import gi
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk, Gdk
Gtk.Window.set_default_icon_from_file(sys.argv[1])
w = Gtk.Window(title='Мои команды')
w.set_wmclass('my-commands', 'MyCommands')
w.set_default_size(700, 520)
w.set_border_width(16)
w.connect('destroy', Gtk.main_quit)
box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12)
w.add(box)
model = Gtk.ListStore(str)
for label in ['AdGuard VPN', 'Яндекс.Диск', 'Диски и файловые системы', 'Сайт АПС', 'Система', 'Журналы']:
    model.append([label])
view = Gtk.TreeView(model=model)
view.append_column(Gtk.TreeViewColumn('Раздел', Gtk.CellRendererText(), text=0))
scroll = Gtk.ScrolledWindow()
scroll.add(view)
box.pack_start(scroll, True, True, 0)
buttons = Gtk.ButtonBox(orientation=Gtk.Orientation.HORIZONTAL)
buttons.set_layout(Gtk.ButtonBoxStyle.END)
box.pack_start(buttons, False, False, 0)
ok = Gtk.Button(label='OK')
leave = Gtk.Button(label='Exit')
buttons.add(ok)
buttons.add(leave)
def execute(*args):
    model, row = view.get_selection().get_selected()
    if row is not None:
        print(model[row][0], flush=True)
        w.destroy()
ok.connect('clicked', execute)
view.connect('row-activated', execute)
leave.connect('clicked', lambda *_: w.destroy())
# Enter always exits when Exit has focus; selection alone does not execute.
def key(window, event):
    if event.keyval == Gdk.KEY_Escape:
        w.destroy()
        return True
    return False
w.connect('key-press-event', key)
tray = Gtk.StatusIcon.new_from_file(sys.argv[1])
tray.set_tooltip_text('Мои команды')
tray.connect('activate', lambda *_: w.present())
w.show_all()
leave.set_can_default(True)
leave.grab_default()
leave.grab_focus()
Gtk.main()
tray.set_visible(False)
PYGTK
}

# Internal execution modes precede graphical initialization.
case "${1:-}" in
    --terminal-child) shift; [ -d "${1:-}" ] || exit 125; terminal_child "$@"; exit $? ;;
    --yandex-report) embedded_yandex_report; exit $? ;;
    --astro) shift; site_config || exit 1; embedded_astro "$@"; exit $? ;;
    --site) shift; site_command "$@"; exit $? ;;
    --help)
        echo 'Мои команды 3.0.0. Запуск: bash menu.sh. Все настройки — через графическое меню.'
        exit 0 ;;
    '') ;;
    *) echo 'Неизвестный параметр.' >&2; exit 2 ;;
esac

for task_dependency in zenity x-terminal-emulator tee mktemp; do
    command -v "$task_dependency" >/dev/null || {
        echo "Не найден компонент: $task_dependency" >&2; exit 1;
    }
done
mkdir -p "$LOG_DIR" "$YANDEX_LOG_DIR" || exit 1
touch "$LOG_FILE" || exit 1
# ============================================================
# ГЛАВНОЕ МЕНЮ
# ============================================================

while true
do

    ACTION_DONE=0
    MAIN=$(main_dialog) || exit 0


    case "$MAIN" in


        "Яндекс.Диск")

            menu_yandex
            ;;


        "AdGuard VPN")

            menu_vpn
            ;;


        "Диски и файловые системы")

            menu_disks
            ;;


        "Сайт АПС")
            menu_site
            ;;

        "Система")

            menu_system
            ;;


        "Журналы")

            menu_logs
            ;;


        "Выход"|"")

            exit 0
            ;;

    esac
done
